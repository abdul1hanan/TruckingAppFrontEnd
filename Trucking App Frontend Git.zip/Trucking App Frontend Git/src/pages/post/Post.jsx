import React from 'react'
import { Card } from "../../components/blog/Card"
export const Post = () => {
  return (
    <Card/>
  )
}

export default Post